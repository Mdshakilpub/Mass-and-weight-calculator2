/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.massandweightcalculator;

/**
 *
 * @author IMRAN
 */
public class MassAndWeightCalculator {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
